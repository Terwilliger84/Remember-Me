package de.kontaktchronik.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import de.kontaktchronik.app.data.AppDatabase
import de.kontaktchronik.app.data.ContactsSyncRepository
import de.kontaktchronik.app.messaging.DirectMessagingService
import de.kontaktchronik.app.model.*
import de.kontaktchronik.app.reminders.DailyReminderWorker
import de.kontaktchronik.app.reminders.QuickActionDispatcher
import kotlinx.coroutines.launch
import java.time.LocalDate

private val BgSlate = Color(0xFF0F172A)
private val CardSlate = Color(0xFF1E293B)
private val BorderSlate = Color(0xFF334155)
private val TextPrimary = Color(0xFFF8FAFC)
private val TextSecondary = Color(0xFFCBD5E1)
private val TextMuted = Color(0xFF94A3B8)
private val AccentSteel = Color(0xFF38BDF8)
private val WarnAmber = Color(0xFFF59E0B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DailyReminderWorker.schedule(this)

        val initialPopupPersonId = intent?.getLongExtra("POPUP_PERSON_ID", -1L) ?: -1L
        val initialPopupReason = intent?.getStringExtra("POPUP_REASON") ?: "Erinnerung"

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = BgSlate,
                    surface = CardSlate,
                    primary = AccentSteel,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                KontaktChronikApp(
                    initialPopupPersonId = initialPopupPersonId,
                    initialPopupReason = initialPopupReason
                )
            }
        }
    }
}

@Composable
fun KontaktChronikApp(
    initialPopupPersonId: Long,
    initialPopupReason: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember { AppDatabase.getInstance(context).dao() }
    val syncRepo = remember { ContactsSyncRepository(db) }
    val directService = remember { DirectMessagingService(context, db) }

    val persons by db.observeAllPersons().collectAsState(initial = emptyList())
    val relations by db.observeAllRelations().collectAsState(initial = emptyList())
    val specialEvents by db.observeAllSpecialEvents().collectAsState(initial = emptyList())
    val directMessages by db.observeAllDirectMessages().collectAsState(initial = emptyList())

    var activeTab by remember { mutableStateOf("Übersicht") }
    var popupPerson by remember { mutableStateOf<PersonEntity?>(null) }
    var popupReason by remember { mutableStateOf(initialPopupReason) }
    var quickMessageText by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }
    var detailPerson by remember { mutableStateOf<PersonEntity?>(null) }
    var syncStatus by remember { mutableStateOf("App-Code: ${directService.getOwnPairingCode()}") }

    LaunchedEffect(persons, initialPopupPersonId) {
        if (initialPopupPersonId > 0 && popupPerson == null) {
            popupPerson = persons.find { it.id == initialPopupPersonId }
        }
    }

    val contactPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            scope.launch {
                val count = syncRepo.syncDeviceContactsWithBirthdays(context.contentResolver)
                syncStatus = "$count Kontakte synchronisiert"
            }
        } else {
            syncStatus = "Kontakt-Berechtigung verweigert"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgSlate)
            .padding(12.dp)
    ) {
        // Kompakte Kopfzeile
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("KontaktChronik v1.0.2", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(syncStatus, color = TextMuted, fontSize = 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CompactButton("Sync") {
                    val hasPerm = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.READ_CONTACTS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (hasPerm) {
                        scope.launch {
                            val count = syncRepo.syncDeviceContactsWithBirthdays(context.contentResolver)
                            syncStatus = "$count Kontakte synchronisiert"
                        }
                    } else {
                        contactPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                    }
                }
                CompactButton("Empfang testen") {
                    scope.launch {
                        val sender = persons.firstOrNull()
                        if (sender != null) {
                            directService.onIncomingPeerMessage(
                                senderPerson = sender,
                                text = "Hallo! Wir kommen nächste Woche zu Besuch!",
                                sharedEventTitle = "Kommt zu Besuch",
                                sharedEventDateIso = LocalDate.now().plusDays(5).toString()
                            )
                            popupReason = "App-Direkt: Kommt zu Besuch"
                            quickMessageText = "Super, wir freuen uns auf euch!"
                            popupPerson = sender
                        }
                    }
                }
                CompactButton("Neu") { showCreateDialog = true }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Navigation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("Übersicht", "Kontakte", "Direkt-Chat", "Timer", "Termine").forEach { tab ->
                val active = activeTab == tab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (active) Color(0xFF334155) else CardSlate, RoundedCornerShape(6.dp))
                        .border(1.dp, BorderSlate, RoundedCornerShape(6.dp))
                        .clickable { activeTab = tab }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(tab, color = if (active) TextPrimary else TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (persons.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardSlate, RoundedCornerShape(8.dp))
                    .border(1.dp, BorderSlate, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Noch keine Kontakte vorhanden", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Tippe oben auf 'Sync', um deine Telefonkontakte nach Geburtstagen zu durchsuchen, auf 'Neu' zum Anlegen, oder lade Beispielkontakte (inkl. Baby Leo ohne eigene Nummer).",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    CompactButton("Beispieldaten anlegen") {
                        scope.launch {
                            val annaId = db.upsertPerson(
                                PersonEntity(
                                    name = "Anna Weber",
                                    birthdayIso = LocalDate.now().plusDays(4).withYear(1992).toString(),
                                    phone = "+491712345678",
                                    email = "anna.weber@beispiel.de",
                                    appPeerId = "KC-ANNA-92",
                                    notes = "Lieblingsblumen: Pfingstrosen",
                                    timerEnabled = true,
                                    timerInterval = 14,
                                    timerUnit = TimerUnit.DAYS.name,
                                    lastContactedIso = LocalDate.now().minusDays(15).toString()
                                )
                            )
                            val leoId = db.upsertPerson(
                                PersonEntity(
                                    name = "Leo Weber (Baby)",
                                    birthdayIso = LocalDate.now().withYear(2026).toString(),
                                    hasNoOwnPhone = true,
                                    notes = "Kleidergröße 68, mag Holzrasseln",
                                    timerEnabled = true,
                                    timerInterval = 1,
                                    timerUnit = TimerUnit.MONTHS.name,
                                    lastContactedIso = LocalDate.now().minusDays(10).toString()
                                )
                            )
                            db.insertRelation(
                                RelationEntity(
                                    fromPersonId = leoId,
                                    toPersonId = annaId,
                                    relationLabel = "Kind von",
                                    isFallbackContact = true
                                )
                            )
                            db.insertRelation(
                                RelationEntity(
                                    fromPersonId = annaId,
                                    toPersonId = leoId,
                                    relationLabel = "Mutter von",
                                    isFallbackContact = false
                                )
                            )
                            db.insertSpecialEvent(
                                SpecialEventEntity(
                                    personId = annaId,
                                    title = "Kommt zu Besuch",
                                    dateIso = LocalDate.now().plusDays(7).toString(),
                                    leadDays = 2,
                                    note = "Mit Baby Leo übers Wochenende"
                                )
                            )
                        }
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(persons) { person ->
                val personRelations = relations
                    .filter { it.fromPersonId == person.id }
                    .mapNotNull { rel -> persons.find { it.id == rel.toPersonId }?.let { rel to it } }
                val personEvents = specialEvents.filter { it.personId == person.id }
                val personMsgs = directMessages.filter { it.personId == person.id }
                val resolved = ContactResolver.resolveTarget(person, personRelations)
                val bdayDays = ContactResolver.daysUntilNextBirthday(person.birthdayIso)
                val nextTimer = ContactResolver.nextTimerDate(person)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardSlate, RoundedCornerShape(8.dp))
                        .border(1.dp, BorderSlate, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(person.name, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                if (resolved.hasAppDirect) {
                                    Text("App (${resolved.appPeerId})", color = AccentSteel, fontSize = 11.sp)
                                }
                                if (person.hasNoOwnPhone) {
                                    Text("Ohne Nr.", color = WarnAmber, fontSize = 11.sp)
                                }
                            }
                            val sub = buildList {
                                person.birthdayIso?.let {
                                    add("Geb.: $it (${ContactResolver.formatUpcomingAge(it)}, in ${bdayDays ?: "-"}T)")
                                }
                                if (person.timerEnabled && nextTimer != null) {
                                    add("Timer: $nextTimer (alle ${person.timerInterval} ${person.timerUnit})")
                                }
                            }.joinToString(" • ")
                            if (sub.isNotEmpty()) {
                                Text(sub, color = TextSecondary, fontSize = 12.sp)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            CompactButton("Pop-up") {
                                popupReason = "Direkt-Erinnerung"
                                quickMessageText = "Hallo ${resolved.targetPersonName.substringBefore(" ")}, herzliche Grüße!"
                                popupPerson = person
                            }
                            CompactButton("Akte") {
                                detailPerson = person
                            }
                        }
                    }

                    if (personRelations.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Verknüpft: " + personRelations.joinToString(", ") { "${it.first.relationLabel} ${it.second.name}" },
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    if (personEvents.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sondertermine: " + personEvents.joinToString(", ") { "${it.title} (${it.dateIso})" },
                            color = AccentSteel,
                            fontSize = 11.sp
                        )
                    }

                    if (personMsgs.isNotEmpty()) {
                        val lastMsg = personMsgs.last()
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "App-Chat (${lastMsg.senderDisplayName}): ${lastMsg.text}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    if (person.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Notiz: ${person.notes}", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    // Dialog: Neuen Kontakt anlegen (inkl. ohne Nummer / Baby, Beziehung, Timer, App-Code)
    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        var bday by remember { mutableStateOf(LocalDate.now().toString()) }
        var noPhone by remember { mutableStateOf(false) }
        var phone by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var appCode by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        var timerInterval by remember { mutableStateOf("14") }
        var relLabel by remember { mutableStateOf("Kind von") }
        var selectedRelTargetId by remember { mutableStateOf(persons.firstOrNull()?.id ?: -1L) }

        Dialog(onDismissRequest = { showCreateDialog = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardSlate, RoundedCornerShape(10.dp))
                    .border(1.dp, BorderSlate, RoundedCornerShape(10.dp))
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Kontakt anlegen", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = bday, onValueChange = { bday = it }, label = { Text("Geburtsdatum (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = noPhone, onCheckedChange = { noPhone = it })
                    Text("Keine eigene Nummer (z. B. Baby)", color = TextSecondary, fontSize = 12.sp)
                }

                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telefon (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("E-Mail (aktiviert Mail-Button)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = appCode, onValueChange = { appCode = it }, label = { Text("App-Code (z. B. KC-ANNA-92)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = timerInterval, onValueChange = { timerInterval = it }, label = { Text("Melde-Timer (Tage)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notiz") }, modifier = Modifier.fillMaxWidth())

                if (persons.isNotEmpty()) {
                    Text("Beziehung zu bestehendem Kontakt:", color = TextSecondary, fontSize = 12.sp)
                    OutlinedTextField(value = relLabel, onValueChange = { relLabel = it }, label = { Text("Rolle (z.B. Kind von, Bruder von)") }, modifier = Modifier.fillMaxWidth())
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CompactButton("Abbrechen") { showCreateDialog = false }
                    CompactButton("Speichern") {
                        if (name.isNotBlank()) {
                            scope.launch {
                                val newId = db.upsertPerson(
                                    PersonEntity(
                                        name = name.trim(),
                                        birthdayIso = bday.trim(),
                                        hasNoOwnPhone = noPhone,
                                        phone = phone.trim(),
                                        email = email.trim(),
                                        appPeerId = appCode.trim().uppercase(),
                                        notes = notes.trim(),
                                        timerEnabled = true,
                                        timerInterval = timerInterval.toIntOrNull() ?: 14,
                                        timerUnit = TimerUnit.DAYS.name,
                                        lastContactedIso = LocalDate.now().toString()
                                    )
                                )
                                if (selectedRelTargetId > 0 && relLabel.isNotBlank()) {
                                    db.insertRelation(
                                        RelationEntity(
                                            fromPersonId = newId,
                                            toPersonId = selectedRelTargetId,
                                            relationLabel = relLabel.trim(),
                                            isFallbackContact = true
                                        )
                                    )
                                }
                                showCreateDialog = false
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog: Kontakt-Akte (Sondertermin hinzufügen, E-Mail/Notiz/App-Code bearbeiten)
    detailPerson?.let { dp ->
        var emailVal by remember(dp) { mutableStateOf(dp.email) }
        var peerVal by remember(dp) { mutableStateOf(dp.appPeerId) }
        var notesVal by remember(dp) { mutableStateOf(dp.notes) }
        var newEvTitle by remember { mutableStateOf("") }
        var newEvDate by remember { mutableStateOf(LocalDate.now().plusDays(3).toString()) }

        Dialog(onDismissRequest = { detailPerson = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardSlate, RoundedCornerShape(10.dp))
                    .border(1.dp, BorderSlate, RoundedCornerShape(10.dp))
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Akte: ${dp.name}", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = emailVal, onValueChange = { emailVal = it }, label = { Text("E-Mail-Adresse") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = peerVal, onValueChange = { peerVal = it }, label = { Text("App-Code (App-zu-App)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notesVal, onValueChange = { notesVal = it }, label = { Text("Notiz") }, modifier = Modifier.fillMaxWidth())

                Text("Neuen Sondertermin eintragen (Umzug, OP, Besuch):", color = TextSecondary, fontSize = 12.sp)
                OutlinedTextField(value = newEvTitle, onValueChange = { newEvTitle = it }, label = { Text("Anlass (z.B. Operation, Besuch)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = newEvDate, onValueChange = { newEvDate = it }, label = { Text("Datum (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CompactButton("Löschen") {
                        scope.launch {
                            db.deletePerson(dp)
                            detailPerson = null
                        }
                    }
                    CompactButton("Speichern") {
                        scope.launch {
                            val updated = dp.copy(
                                email = emailVal.trim(),
                                appPeerId = peerVal.trim().uppercase(),
                                notes = notesVal.trim()
                            )
                            db.updatePerson(updated)
                            if (newEvTitle.isNotBlank()) {
                                db.insertSpecialEvent(
                                    SpecialEventEntity(
                                        personId = dp.id,
                                        title = newEvTitle.trim(),
                                        dateIso = newEvDate.trim(),
                                        leadDays = 1
                                    )
                                )
                            }
                            detailPerson = null
                        }
                    }
                }
            }
        }
    }

    // Aufploppende Erinnerung inkl. App-zu-App Direkt-Chat & Fallback auf WhatsApp/SMS/Anruf/Mail
    popupPerson?.let { p ->
        val relPairs = relations
            .filter { it.fromPersonId == p.id }
            .mapNotNull { rel -> persons.find { it.id == rel.toPersonId }?.let { rel to it } }
        val resolved = ContactResolver.resolveTarget(p, relPairs)

        Dialog(onDismissRequest = { popupPerson = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardSlate, RoundedCornerShape(10.dp))
                    .border(1.dp, BorderSlate, RoundedCornerShape(10.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(p.name, color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(popupReason, color = AccentSteel, fontSize = 13.sp)

                resolved.warningNotice?.let { warning ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF3B2F1E), RoundedCornerShape(6.dp))
                            .border(1.dp, WarnAmber, RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Text(warning, color = Color(0xFFFDE68A), fontSize = 12.sp)
                    }
                }

                OutlinedTextField(
                    value = quickMessageText,
                    onValueChange = { quickMessageText = it },
                    label = { Text("Direkt-Antwort / Gruß", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CompactButton(
                        if (resolved.hasAppDirect) "App-Direkt (${resolved.appPeerId})" else "App-Direkt (Fallback)"
                    ) {
                        scope.launch {
                            directService.sendDirectOrFallback(
                                person = p,
                                resolved = resolved,
                                text = quickMessageText.ifBlank { "Herzliche Grüße!" }
                            )
                            popupPerson = null
                        }
                    }
                    CompactButton("WhatsApp") {
                        QuickActionDispatcher.openWhatsApp(context, resolved.phone, quickMessageText)
                    }
                    CompactButton("Anruf") {
                        QuickActionDispatcher.startPhoneCall(context, resolved.phone)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CompactButton("SMS") {
                        QuickActionDispatcher.openSms(context, resolved.phone, quickMessageText)
                    }
                    CompactButton("Telegram") {
                        QuickActionDispatcher.openTelegram(context, resolved.phone)
                    }
                    CompactButton("Signal") {
                        QuickActionDispatcher.openSignal(context, resolved.phone)
                    }
                    if (resolved.email.isNotBlank()) {
                        CompactButton("Mail") {
                            QuickActionDispatcher.openEmail(context, resolved.email, popupReason)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    CompactButton("Kontaktiert") {
                        scope.launch {
                            db.updatePerson(p.copy(lastContactedIso = LocalDate.now().toString()))
                            popupPerson = null
                        }
                    }
                    CompactButton("Schließen") { popupPerson = null }
                }
            }
        }
    }
}

@Composable
fun CompactButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(Color(0xFF334155), RoundedCornerShape(6.dp))
            .border(1.dp, BorderSlate, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
